A program kiválaszt az "adatbázisából" egy kettő betűs szót, amit ki kell találnia a játékosnak.
Jelezzük minden betűről, hogy van e benne, illetve azt is, hogy jó helyen van e a betű.
