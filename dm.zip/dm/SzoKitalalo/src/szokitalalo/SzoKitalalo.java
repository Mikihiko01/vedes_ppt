package szokitalalo;

import java.util.Scanner;

public class SzoKitalalo {
    
    static final int SZO_HOSSZ = 2;
    static String szo, tipp;
    static char[] visszaJelzes;
    
    public static void main(String[] args) {
        visszaJelzes = feltolt('_');
        szo = kivalasztottSzo();
        
        /* DEBUG */
        //szo = "boci";
        /* DEBUG vége */
        
        boolean kitalalta = false;
        do {            
            tipp = szoBekeres();
            kitalalta = szoVizsgalat();
            allastMutat();
        } while (!kitalalta);
    }

    private static char[] feltolt(char c) {
        char[] tomb = new char[SZO_HOSSZ];
        for (int i = 0; i < SZO_HOSSZ; i++) {
            tomb[i] = c;
        }
        return tomb;
    }
    
    private static String kivalasztottSzo() {
        String[] szavak = {"ab", "ad", "be", "bo", "te"};
        allastMutat();
        return szavak[(int)(Math.random() * szavak.length)];
    }
    
    private static String szoBekeres() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Mi lehet a szó: ");
        return sc.nextLine();
    }

    /*todo: 
    dupla betűnél, ha az első van benne, akkor a 2. betűt is jelöli, pl:
    boci kitalálandó
    abba beírt
    _^^_ jelölés
    van, amikor kell jelölni:
    adag kitalálandó
    abba beírt
    a___ jelölés, de ez kellene: a__^
    */
    private static boolean szoVizsgalat() {
        boolean teljesTalalat = szo.equals(tipp);
        if(teljesTalalat){
            System.out.println("ez volt:");
            visszaJelzes = szo.toCharArray();
        }else{
            for (int i = 0; i < szo.length(); i++) {
                char vizsgaltBetu = tipp.charAt(i);
                if(szo.contains(vizsgaltBetu+"")){
                    if(vizsgaltBetu == szo.charAt(i)){
                        visszaJelzes[i] = vizsgaltBetu;
                    }else if(!korabbanJeloltuk(vizsgaltBetu, i) || tobbVanBenne(vizsgaltBetu)){
                        visszaJelzes[i] = '^';
                    }
                }else{
                    visszaJelzes[i] = '_';
                }
            }
        }
        return teljesTalalat;
    }

    private static void allastMutat() {
        if(tipp != null){
            betuketKiir(tipp.toCharArray());
            System.out.println("");
        }
        betuketKiir(visszaJelzes);
        System.out.println("");
    }

    private static void betuketKiir(char[] tomb) {
        for (int i = 0; i < SZO_HOSSZ; i++) {
            System.out.print(tomb[i] + " ");
        }
    }

    private static boolean korabbanJeloltuk(char betu, int eddig) {
        int i = 0;
        while(i < eddig && !(tipp.charAt(i) == betu)){
            i++;
        }
        return i < eddig;
    }
    
    private static boolean tobbVanBenne(char vizsgaltBetu) {
        int db = 0;
        for (int i = 0; i < SZO_HOSSZ; i++) {
            if(szo.charAt(i) == vizsgaltBetu){
                db++;
            }
        }
        return db > 1;
    }
}
