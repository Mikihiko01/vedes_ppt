<?php

include_once './Ab.php';

class Adatmentes {

    private $kapcsolat;

    function __construct() {
        $this->kapcsolat = new Ab();
    }

    function mentes() {

        $sql = "SELECT * FROM helyszin";


        $eredmeny = $this->kapcsolat->getKapcsolat()->query($sql);
        $adatok = array();
        if ($eredmeny->num_rows > 0) {

            while ($sor = $eredmeny->fetch_assoc()) {

                $adat = json_encode($sor, JSON_UNESCAPED_UNICODE);
                array_push($adatok, $adat);
            }


            $fajl = fopen("adatok.json", "w") or die("A fájlt nem lehet megnyitni");
            fwrite($fajl, "[");
            for ($index = 0; $index < count($adatok); $index++) {
                fwrite($fajl, $adatok[$index]);
                if ($index !== count($adatok) - 1) {
                    fwrite($fajl, ",");
                }
            }

            fwrite($fajl, "]");


            fclose($fajl);


            echo "Sikeres adtmentés!";
        } else {

            echo "Üres az adattábla!";
        }
//kapcsolat bezárása
        $this->kapcsolat->kapcsolatBezar();
    }

}
