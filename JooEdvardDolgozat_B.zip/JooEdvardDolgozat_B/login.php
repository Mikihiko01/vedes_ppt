<!DOCTYPE html>

<html>
    <head>
        <link href="formaz.css" rel="stylesheet" type="text/css"/>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include_once './Ab.php';
        $adatbazis = new Ab();

        if (!empty($_POST["user"]) && !empty([$_POST["pass"]])) {
            session_start();
            $user = $_POST["user"];
            $pass = md5($_POST["pass"]);
            $SQL = 'SELECT * from felhasznalok where user="' . $user . '" and pass="' . $pass . '" and statusz = 1';
            $adat = $adatbazis->getKapcsolat()->query($SQL);
            if ($adat->num_rows > 0) {
                $row = $adat->fetch_assoc();
                $_SESSION["user"] = $row["felhasznalonev"];
                if ($row["statusz"] = 1) {
                    $_SESSION["adminE"] = "admin";
                } else {
                    $_SESSION["adminE"] = "dolgozó";
                }


                header("Location: logout.php");
            } else {

                echo '<div class="hiba">Hibás felhasználónév vagy jelszó!</div>';
                echo '<div class="hiba">Lehetséges, hogy nem rendelkezik megfelelő jogkörrel!</div>';
            }
        } else {
            
        }
        ?>
        <form method="post" action="">
            <fieldset>
                <legend>Bejelentkezés</legend>
                <input type="text" name="user" id="user" placeholder="Felhasználónév" required>
                <br>
                <input type="password" name="pass" id="pass" placeholder="Jelszó" required>
                <br> 
                <input type="submit" name="send" id="send" value="Login">
            </fieldset>
            <div id="szin"></div>

        </form>
    </body>
</html>
