-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2021. Okt 20. 13:35
-- Kiszolgáló verziója: 10.4.20-MariaDB
-- PHP verzió: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `faloda`
--
CREATE DATABASE IF NOT EXISTS `faloda` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
USE `faloda`;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `felhasznalok`
--

DROP TABLE IF EXISTS `felhasznalok`;
CREATE TABLE IF NOT EXISTS `felhasznalok` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `user` text COLLATE utf8_hungarian_ci NOT NULL,
  `pass` text COLLATE utf8_hungarian_ci NOT NULL,
  `felhasznalonev` text COLLATE utf8_hungarian_ci NOT NULL,
  `statusz` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- TÁBLA KAPCSOLATAI `felhasznalok`:
--

--
-- A tábla adatainak kiíratása `felhasznalok`
--

INSERT INTO `felhasznalok` (`ID`, `user`, `pass`, `felhasznalonev`, `statusz`) VALUES
(1, 'elso', '6e317dbf8a7967e18842c532069e11a5', 'Elso Marcell', 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `helyszin`
--

DROP TABLE IF EXISTS `helyszin`;
CREATE TABLE IF NOT EXISTS `helyszin` (
  `helyszinAzon` int(11) NOT NULL AUTO_INCREMENT,
  `helyszinNev` varchar(200) COLLATE utf8_hungarian_ci NOT NULL,
  `irszam` int(11) NOT NULL,
  `cim` varchar(500) COLLATE utf8_hungarian_ci NOT NULL,
  `telefon` int(11) NOT NULL,
  `aktiv` tinyint(1) NOT NULL,
  PRIMARY KEY (`helyszinAzon`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- TÁBLA KAPCSOLATAI `helyszin`:
--

--
-- A tábla adatainak kiíratása `helyszin`
--

INSERT INTO `helyszin` (`helyszinAzon`, `helyszinNev`, `irszam`, `cim`, `telefon`, `aktiv`) VALUES
(1, 'A38 Hajó', 1113, 'Petőfi híd budai hídfő', 4643940, 1),
(2, 'Bárka Kikötő a Ráday utcában', 1092, 'Ráday utca', 0, 0),
(3, 'Bem', 1024, 'Margit krt. 5/b.', 3168708, 0),
(4, 'Budapesti Európai Ifjúsági Központ', 1024, 'Zivatar u. 1-3.', 2124080, 1),
(5, 'Cervantes Intézet', 1000, 'Vörösmarty u. 32.', 0, 0),
(6, 'Cinema City Csepel Plaza', 1212, 'Rákóczi F. út 154-170.', 4258111, 1),
(7, 'Cinema City Új Udvar', 1036, 'Bécsi út 38-44.', 4378383, 0),
(8, 'Cirko-Gejzír', 1055, 'Balassi Bálint u. 15-17.', 2690904, 0),
(9, 'Corvin Budapest Filmpalota', 1082, 'Corvin köz 1.', 4595050, 1),
(10, 'FilmesHáz', 1092, 'Ráday utca 31/K', 0, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
