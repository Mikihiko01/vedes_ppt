<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link href="formaz.css" rel="stylesheet" type="text/css"/>
        <title>Kijelentkezés</title>
    </head>
    <body>

        <?php
        session_start();
        echo '<a href="login.php"  id="jobb">Kijelentkezés</a>';
        echo '<h2>Üdvözöllek! <br> felhasználó: ' . $_SESSION["user"] . " jogkör: " . $_SESSION["adminE"].'</h2>';
        include_once './Ab.php';
        $adatbazis = new Ab();
        $adatbazis->kiir("helyszin", 1);
        if (isset($_POST["kuld"])) {
            include_once './Adatmentes.php';
            $mentes = new Adatmentes();
            $mentes->mentes();
        }
        ?>
        <form action="" method="post">
            <div>
            <input type="submit" value="Mentés" name="kuld" id="kuld">
            </div>
        </form>
    </body>
</html>
