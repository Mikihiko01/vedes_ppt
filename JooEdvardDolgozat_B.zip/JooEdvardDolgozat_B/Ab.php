<?php

class Ab {

    //osztály változók
    //láthatóságok: private, public, protected
    private $host = "localhost";
    private $felhazsnalonev = "root";
    private $jelszo = "";
    private $abNev = "faloda";
    private $kapcsolat;

    public function __construct() {
	$this->kapcsolat = new mysqli($this->host, $this->felhazsnalonev, $this->jelszo, $this->abNev);
	$szoveg = "";
	if ($this->kapcsolat->connect_error) {
	    //$szoveg="<p>Hiba az adatbázishoz csatlakozáskor!</p>";
	    $szoveg = "<p>Hiba: " . $this->kapcsolat->connect_error . ".</p>";
	}

        
	//ékezetes betűk
	$this->kapcsolat->query("SET NAMES UTF8");
	$this->kapcsolat->query("set character set UTF8");
	$this->kapcsolat->query("set collation_connection='utf8_hungary_ci'");

	echo $szoveg;
    }

    function getKapcsolat() {
        return $this->kapcsolat;
    }

        public function kapcsolatBezar() {
	$this->kapcsolat->close();
	//echo "Kapcsolat zárva.";
    }

    public function torol($tablaNeve) {
	$sql = "DELETE FROM " . $tablaNeve;
	//$sql="TRUNCAT ".$tablaNeve;
	//echo $sql;
	$torles = $this->kapcsolat->query($sql);
	$szoveg = "";
	if ($torles === TRUE) {
	    $szoveg = "Sikeres adatörlés!";
	} else {
	    $szoveg = 'Sikertelen adattörlés!';
	}
	return $szoveg;
    }

    function adatlekerTomb($melyikOszlop, $tabla) {
	$sql = "SELECT " . $melyikOszlop . " FROM " . $tabla;
	//echo $sql;
	$adatok = $this->kapcsolat->query($sql);
	$tomb = array();
	if ($adatok->num_rows > 0) {
	    while ($sor = $adatok->fetch_row()) {
		array_push($tomb, $sor[0]);
	    }
	}
	return $tomb;
    }

 
	public function modosit($tabla, $RegiErtek, $UjErtek, $melyikOszlop, $melyikTulajdonsag){
	    //segítség: https://www.w3schools.com/php/php_mysql_update.asp
	    //$SQL parancs
	    //UPDATE `kartya` SET `formaAzon`=8 WHERE `KartyaAzon=2
	    $sql="UPDATE $tabla SET $melyikOszlop=$UjErtek WHERE $melyikTulajdonsag=$RegiErtek";
	    //sql parancs lefutatása query()
	    $lekerdezes=$this->kapcsolat->query($sql);
	    //ellenörzés sikeres volt-e a módosítás nem, majd vissazjelzés a felhazsnálónak
	    if($lekerdezes===TRUE)
	    {
		$szoveg="Sikeres módosítás!";
	    }
	    else
	    {
		$szoveg="Sikertelen módosítás!";
	    }
	    echo $szoveg;
	    //módosított tábla össze értékének kiírása, táblázatos formában
	    //külön eljárás készítése erre
	    $this->kiir($tabla);
	    
	}
	
	public function kiir($tabla, $honnan) {
	    //akármilyen tábla kiírása táblázatos formában
	    //adatok <- táblázat a törzsi része
	    $adatok=$this->lekerdez1($tabla);
	    
	    if($adatok->num_rows >0)
	    {
		echo "<table>";
		echo "<tr>";
		//fejléc sor
		//oszlopok nevei<- táblázat fejléce	
		$oszlopok= $this->oszlopok($tabla);
		$oszlopokSzama=$oszlopok->num_rows;
		while ($sor = $oszlopok->fetch_row()) {
		    echo "<th>";
		    echo $sor[0];
		    echo "</th>";
		}
		echo "</tr>";
		while ($sor=$adatok->fetch_row())
		{
		    echo "<tr>";
		    for ($index = $honnan; $index < $oszlopokSzama; $index++) {
			echo "<td>";
			echo $sor[$index];
			echo "</td>";
		    }
		    echo "</tr>";
		}
		
		echo "</table>";
	    }
	    else{
		echo "Nincsenek adatok a ".$tabla. " táblában!";
	    }
	    
	}
	
	public function oszlopok($tablaNeve)
	{
	    $sql="Show columns FROM ".$tablaNeve;
	    $lekerdezes=$this->kapcsolat->query($sql);
	    return $lekerdezes;
	}
	
	public function lekerdez1($tablaNeve) {
	    $sql="SELECt * FROM ".$tablaNeve;
	    $lekerdezes=$this->kapcsolat->query($sql);
	    return $lekerdezes;
	}
	
    }
    